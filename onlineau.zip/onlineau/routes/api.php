<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
Route::post('login','PassportController@login');
Route::post('register','PassportController@register');

Route::middleware('auth:api')->group( function () {
    Route::get('categories','api/apiauc@index');//show catgoery
    Route::post('addproduct','api/apiauc@store'); // add product
    Route::get('showproduct/{id}','api/apiauc@show');// show product
    Route::get('inforramtionaus/{id}','api/apiauc@auc');// show user and auction
    Route::post('add_auc','api/apiauc@add_auc'); // add product

});


