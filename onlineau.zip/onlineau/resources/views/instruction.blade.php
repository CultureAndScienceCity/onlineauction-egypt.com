<!DOCTYPE html>
<html>

<head>
    <title> Instructions</title>
    <link rel="stylesheet" href="{{URL::asset('ins/css/style.css')}}">
    <link rel="stylesheet" href="{{URL::asset('ins/assets/templates/css/bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{URL::asset('ins/assets/templates/css/owl.carousel.min.css')}}">
    <link rel="stylesheet" href="{{URL::asset('ins/assets/templates/css/style.css')}}">
    <link rel="shortcut icon" href="https://www.pngmart.com/files/8/Auction-PNG-Free-Image.png" type="image/x-icon">
</head>

<body>
    <div class="site-navigation">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="navbar navbar-expand-lg navigation-area">
                        <!-- Site Branding -->
                        <div class="site-branding">
                                <a class="site-logo" href="{{URL('/')}}">
                                    <img src="{{asset('ins/assets/images/w.png')}}" width="230px" height="20px"
                                        style="padding: 20px" alt="Site Logo">
                                </a>
                        </div><!-- /.site-branding -->
                        <div class="mainmenu-area">
                            <nav class="menu" style="display: block;">
                                <ul id="nav">
                                    <li><a href="{{URL('/')}}">Home</a></li>

                                    <li><a href="{{URL('/about')}}">About</a>
                                    </li>
                                    @guest
                                    <li >
                                        <a  href="{{ route('login') }}">{{ __('Login') }}</a>
                                    </li>
                                    @if (Route::has('register'))
                                        <li class="nav-item">
                                            <a class="nav-link" href="{{ route('register') }}">{{ __('Register') }}</a>
                                        </li>
                                    @endif
                                @else
                                    <li >



                                            <a  href="{{ route('logout') }}"
                                               onclick="event.preventDefault();
                                                             document.getElementById('logout-form').submit();">
                                                {{ __('Logout') }}
                                            </a>

                                            <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                                @csrf
                                            </form>

                                    </li>
                                @endguest
                                    <li><a href="file:///C:/graduation project/category/index.html">Categories</a>
                                    </li>
                                    <li><a href="{{URL('instruction')}}">Instructions</a>
                                    </li>
                                    <li><a href="file:///C:/graduation project/home/contact.html">Contact</a></li>

                                    <!--<li class="dropdown-trigger">
                                    <a href="javascript:void(0)">Account</a>
                                    <ul class="dropdown-content">
                                        <li><a href="#">Login</a></li>
                                        <li><a href="#r">Register</a>
                                        </li>
                                    </ul>-->
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>




    <div class="container urf">
        <h1>Instructions</h1>
        <div class="container">
        </div>
        <div class="box">
            <h2>Step 1</h2>
            <br><br><br><br>
            <h3>Create An Account</h3>

        </div>
        <div class="box">
            <h2>Step 2</h2>
            <br><br><br><br>
            <h3>Choose The Category</h3>
        </div>

        <div class="box">
            <h2>Step 3</h2>
            <br><br><br><br>
            <h3>Choose Product</h3>
        </div>



        <div class="box">
            <h2>Step 4</h2>
            <br><br><br><br>
            <h3>Bidding</h3>
        </div>


        <div class="box">
            <h2>Step 5</h2>
            <br><br> <br><br>
            <h3>Choose Payment Method</h3>
        </div>


        <div class="box">
            <h2>Step 6</h2>
            <br><br> <br> <br>
            <h3>Payment And Receipt</h3>
        </div>
    </div>
    </div>


    <!-- For footer  -->
    <footer class="bg-white">
        <div class="container py-5">
            <div class="row py-3">
                <div class="col-lg-2 col-md-6 mb-4 mb-lg-0">
                    <h6 class="text-uppercase font-weight-bold mb-4">About</h6>
                    <ul class="list-unstyled mb-0">
                        <li class="mb-2"><a href="file:///C:/graduation project/home/contact.html" class="text-muted">Contact Us</a></li>
                        <li class="mb-2"><a href="file:///C:/graduation project/about/index.html" class="text-muted">About Us</a></li>
                        <li class="mb-2"><a href="#" class="text-muted">Stories</a></li>
                        <li class="mb-2"><a href="#" class="text-muted">Press</a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-6 mb-4 mb-lg-0">
                    <h6 class="text-uppercase font-weight-bold mb-4">Help</h6>
                    <ul class="list-unstyled mb-0">
                        <li class="mb-2"><a href="#" class="text-muted">Payments</a></li>
                        <li class="mb-2"><a href="#" class="text-muted">Shipping</a></li>
                        <li class="mb-2"><a href="#" class="text-muted">Cancellation</a></li>
                        <li class="mb-2"><a href="#" class="text-muted">Returns</a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-6 mb-4 mb-lg-0">
                    <h6 class="text-uppercase font-weight-bold mb-4">Policy</h6>
                    <ul class="list-unstyled mb-0">
                        <li class="mb-2"><a href="#" class="text-muted">Return Policy</a></li>
                        <li class="mb-2"><a href="#" class="text-muted">Terms Of Use</a></li>
                        <li class="mb-2"><a href="#" class="text-muted">Security</a></li>
                        <li class="mb-2"><a href="#" class="text-muted">Privacy</a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-6 mb-4 mb-lg-0">
                    <h6 class="text-uppercase font-weight-bold mb-4">Company</h6>
                    <ul class="list-unstyled mb-0">
                        <li class="mb-2"><a href="{{ route('login') }}" class="text-muted">Login</a></li>
                        <li class="mb-2"><a href="{{ route('register') }}" class="text-muted">Register</a></li>
                        <li class="mb-2"><a href="#" class="text-muted">Sitemap</a></li>
                        <li class="mb-2"><a href="#" class="text-muted">Our Products</a></li>
                    </ul>
                </div>
                <div class="col-lg-4 col-md-6 mb-lg-0">
                    <h6 class="text-uppercase font-weight-bold mb-4">Registered Office Address</h6>
                    <p class="text-muted mb-4">Here , write the complete address of the Registered office address along
                        with telephone number.</p>
                    <ul class="list-inline mt-4">
                        <li class="list-inline-item"><a href="#" target="_blank" title="twitter"><i
                                    class="fab fa-2x fa-twitter"></i></a></li>
                        <li class="list-inline-item"><a href="#" target="_blank" title="facebook"><i
                                    class="fab fa-2x fa-facebook-f"></i></a></li>
                        <li class="list-inline-item"><a href="#" target="_blank" title="instagram"><i
                                    class="fab fa-2x fa-instagram"></i></a></li>
                        <li class="list-inline-item"><a href="#" target="_blank" title="pinterest"><i
                                    class="fab fa-2x fa-youtube"></i></a></li>
                        <li class="list-inline-item"><a href="#" target="_blank" title="vimeo"><i
                                    class="fab fa-2x fa-google"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
        <hr class="p-0 m-0 b-0">
        <div class="bg-light py-2">
            <div class="container text-center">
                <div class="copyright"><p>Copyright © 2022 All Rights reserved by: <a href="{{URL('/')}}">Online Auction</a>
            </div>
        </div>
    </footer>



    <script src="{{URL::asset('ins/assets/templates/js/jquery.js')}}"></script>
    <script src="{{URL::asset('ins/assets/templates/js/bootstrap.min.js')}}"></script>
    <script src="{{URL::asset('ins/assets/templates/js/main.js')}}"></script>

</body>

</html>
