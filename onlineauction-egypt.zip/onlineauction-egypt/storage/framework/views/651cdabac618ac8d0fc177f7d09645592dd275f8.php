<!Doctype html>

<html lang="en-gb" class="no-js">
  <head>
    <meta charset="utf-8">
	<title>Login</title>
    <link rel="shortcut icon" href="https://www.pngmart.com/files/8/Auction-PNG-Free-Image.png" type="image/x-icon">
    <meta name="author" content="">
    <meta name="keywords" content="">
    <meta name="description" content="">

	<!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">


     <!--styles -->
    <link href="<?php echo e(URL::asset('public/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('public/css/font-awesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('public/js/owl-carousel/owl.carousel.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('public/js/owl-carousel/owl.theme.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('public/js/owl-carousel/owl.transitions.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('public/css/magnific-popup.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('public/css/animate.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(URL::asset('public/css/etlinefont.css')); ?>">
    <link href="<?php echo e(URL::asset('public/css/style.css')); ?>" type="text/css"  rel="stylesheet"/>
    <link rel="stylesheet" href="<?php echo e(URL::asset('public/css/signup.css')); ?>">

</head>


	<body  data-spy="scroll" data-target="#main-menu">
        
     <?php echo $__env->yieldContent('content'); ?>
     <script type="text/javascript" src="public/js/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="public/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="public/js/owl-carousel/owl.carousel.js"></script>
    <script type="text/javascript" src="public/js/jquery.flexslider-min.js"></script>
    <script type="text/javascript" src="public/js/jquery.magnific-popup.min.js"></script>
    <script type="text/javascript" src="public/js/easing.js"></script>
    <script type="text/javascript" src="public/js/jquery.easypiechart.js"></script>
    <script type="text/javascript" src="public/js/jquery.appear.js"></script>
    <script type="text/javascript" src="public/js/jquery.parallax-1.1.3.js"></script>
    <script type="text/javascript" src="public/js/jquery.mixitup.min.js"></script>
    <script type="text/javascript" src="public/js/custom.js"></script>
</body>
</html>
<?php /**PATH /home/mudavmuz/onlineauction-egypt.com/resources/views/layouts/app.blade.php ENDPATH**/ ?>